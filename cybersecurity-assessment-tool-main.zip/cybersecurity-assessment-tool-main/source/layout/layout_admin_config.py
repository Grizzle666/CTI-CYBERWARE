import tkinter as tk
import requests
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup


global start_url
window = tk.Tk()
# to rename the title of the window
window.title("Octagon Crawler")
# pack is used to show the object in the window
label = tk.Label(window, text = "Octagon").pack()
# Once the frames are created then you are all set to add widgets in both the frames.

inputtxt = tk.Text(window, height = 10,
                width = 25,
                bg = "pink")
inputtxt.pack()
def save_report():
    # Convert the array to a DataFrame
    df = pd.DataFrame(crawled_links)
    # Save the DataFrame to a CSV file
    df.to_csv('myarray.csv', index=False, header=False)
    
def retrieve_input():
    inputx = inputtxt.insert('1.0',start_url)   


Display = tk.Button(window, height = 2,
                 width = 20, 
                 text ="Start Crawling ",
                 command = retrieve_input)
Display.pack()


savebtn = tk.Button(window, height = 2,
                 width = 20, 
                 text ="Save Report",
                 command = save_report)
savebtn.pack()

start_url=input("Please Enter a URL to Crawl....")



    # Initialize a list to store the crawled links
crawled_links = []

def crawl(url):
    try:
        # Send an HTTP GET request to the URL
        response = requests.get(url)

        # Check for successful response
        if response.status_code == 200:
            # Parse the HTML content of the page
            soup = BeautifulSoup(response.text, 'html.parser')

            # Find and extract links
            for link in soup.find_all('a'):
                href = link.get('href')
                if href and href.startswith('http'):
                    crawled_links.append(href)

    except Exception as e:
        print(f"Error: {e}")

# Start crawling from the initial URL
crawl(start_url)

# Print the crawled links



for link in crawled_links:
    print(link)
    inputx = inputtxt.insert('1.0',link,"\n")
    



window.mainloop()


    