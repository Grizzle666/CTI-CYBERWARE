import tkinter as tk
import requests
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
import requests
from tkinter import messagebox
import tkinter as tk
from tkinter import PhotoImage


def suface_web():
    crawled_links = []
    scraped_links = []
    images_list = [] 
    start_url=""
    window = tk.Tk()
    # to rename the title of the window
    window.title("Octagon Crawler")
    # pack is used to show the object in the window
    label = tk.Label(window, text = "Octagon").pack()
    #Once the frames are created then you are all set to add widgets in both the frames.
    # # Load the image
    image = PhotoImage(file="source/resources/imt.png")
    # Create a label to display the image
    image_label = tk.Label(window, image=image)
    image_label.pack()
    searchtxt = tk.Text(window, height = 2,width = 40,
                bg = "yellow")
    searchtxt.pack()
    inputtxt = tk.Text(window, height = 5,
                width = 40,
                bg = "pink")
    inputtxt.pack()
    scraptxt = tk.Text(window, height = 5,
                width = 40,
                bg = "green")
    scraptxt.pack()
    scrapcontent = tk.Text(window, height = 10,
                width = 25,
                bg = "green")
    scrapcontent.pack()
    def crawl(url):
        try:
            # Send an HTTP GET request to the URL
            response = requests.get(url)
            # Check for successful response
            if response.status_code == 200: 
                #Parse the HTML content of the page
                soup = BeautifulSoup(response.text, 'html.parser')
                # Find and extract links
                for link in soup.find_all('a'):
                    href = link.get('href')
                    if href and href.startswith('http'):
                        crawled_links.append(href)
        except Exception as e:
                        print(f"Error: {e}")
    def save_report():
         # Convert the array to a DataFrame
         df_image = pd.DataFrame(images_list)
         df = pd.DataFrame(crawled_links)
         # Save the DataFrame to a CSV file
         df.to_csv('links.csv', index=False, header=False)
         df_image.to_csv('images.csv', index=False, header=False)
         tk.messagebox.showinfo("Save Successfully.",  "Data saved") 
    def search():
              start_url =searchtxt.get(1.0, "end-1c") 
              crawl(start_url)
              for link in crawled_links:
                   print(link)
                   inputtxt.insert('1.0',link,"\n")
                   scrap(start_url)
                   scrapword(start_url)
    Display = tk.Button(window, height = 2,
                 width = 20, 
                 text ="Start Crawling ",
                 command = search)
    Display.pack()
    savebtn = tk.Button(window, height = 2,
                 width = 50, 
                 text ="Save Report",
                 command = save_report)
    savebtn.pack()
    # Making a GET request 
    def scrap(url):
        #Making a GET request 
        r = requests.get(url) 
        # Parsing the HTML 
        soup = BeautifulSoup(r.content, 'html.parser') 
        images = soup.select('img') 
        for image in images: 
             src = image.get('src')
             alt = image.get('alt') 
             images_list.append({"src": src, "alt": alt}) 
             for image in images_list: 
                  scraptxt.insert('1.0',image,"\n")
                  print(image)
    def scrapword(url):
          # Making a GET request 
          r = requests.get(url) 
          # Parsing the HTML 
          soup = BeautifulSoup(r.content, 'html.parser') 
          s = soup.find('div', class_='entry-content') 
          content = s.find_all('p') 
          scrapword.insert('1.0',content,"\n")
          print(content)
    window.mainloop()

